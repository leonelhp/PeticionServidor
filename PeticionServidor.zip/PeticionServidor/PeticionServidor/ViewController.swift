//
//  ViewController.swift
//  PeticionServidor
//
//  Created by LEONEL HERNANDEZ PEREZ on 05/04/17.
//  Copyright © 2017 LeonelHP. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var wISBN: UITextField!
    @IBOutlet weak var wSalida: UITextView!
    
    @IBAction func fLimpia(_ sender: Any) {
        wISBN.text = ""
    }
    
    @IBAction func Busca(_ sender: Any) {

        let wTex:String = wISBN.text!
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:\(wTex)"

        let url = NSURL(string: urls)
        let datos:NSData? = NSData(contentsOf: url! as URL)
        let texto = NSString(data: datos! as Data, encoding: String.Encoding.utf8.rawValue)
        print(texto!)
        wSalida.text = texto! as String
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

